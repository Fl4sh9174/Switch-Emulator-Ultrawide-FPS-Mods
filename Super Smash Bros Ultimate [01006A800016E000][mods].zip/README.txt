==== FPS Mod Usage ====

=== For Yuzu-Based Emulators ===

Make sure that the Following Settings are Disabled:

  - Sync Framerate to Video Playback
  - CPU Overclock

Disabling the 1st Setting makes Sure that some Final Smashes aren't Playing longer than they Actually should.
Disabling the 2nd Setting prevents the Game from Speeding Up even more in some Areas.

=== For Ryujinx-Based Emulators ===

The FPS Mods don't work Exactly as they should on this Emulator.
To use them anyway make sure you've set these Settings for the Game:

  - VSync Disabled
  - Speed Limit Set (120 = 200%, 180 = 300%, 240 = 400%)

VSync may have to be set to "Custom" to set a Speed Limit.
You also have to Remove the "[...]v2.pchtxt" File from the FPS Mods to prevent the Emulator from Crashing on Load.