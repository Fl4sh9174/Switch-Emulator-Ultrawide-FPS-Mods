==== Aspect Ratio State ====

Here's the current state of the Aspect Ratio mods.

What Works:

  - In-match camera zoom
  - In-match Character off-screen detection

Bugs:

  - UI isn't fully adjusted
  - In-match death-zone is still 16:9

==== FPS Mod State ====

Here's the current state of the Definitive Edition FPS mods.

What Works:

  - General in-match movement speed
  - General audio playback speed
  - UI cursor movement speed
  - Separate Training Mode speeds (120 FPS only)
  - Item usage
  - Classic Mode
  - Story Mode (and all related ghost fights)

Bugs:

  - UI animations/elements run sped up
  - Final Smashes with a video cutscene play sped up (though total move duration matches 60 FPS)
  - Some Final Smashes have sped-up effects (Bowser Jr., for example)
  - In-match movement may become sped up at the start of a boss fight

==== FPS Mod Usage ====

=== For Yuzu-Based Emulators ===

Make sure the following settings are disabled:

  - Sync Framerate to Video Playback
  - CPU Overclock

Disabling the 1st setting ensures some Final Smashes do not play longer than they should.
Disabling the 2nd setting prevents the game from speeding up even more in certain areas.

=== For Ryujinx-Based Emulators ===

The FPS mods do not work quite as intended on this emulator.
To use them anyway, configure these game settings:

  - VSync: Disabled (set to "Custom" if the speed limit doesn't show by default)
  - Speed Limit: Set above 100% using the formula below

Speed limit formula: 100 / 60 * [New FPS]
Example for 120 FPS: 100 / 60 * 120 = 200%

You also have to remove the "[...]v2.pchtxt" file from the FPS mod you plan to use to prevent the emulator from crashing on load.